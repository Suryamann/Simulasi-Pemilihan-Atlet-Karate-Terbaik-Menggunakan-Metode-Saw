-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Waktu pembuatan: 31. Desember 2018 jam 17:33
-- Versi Server: 5.1.41
-- Versi PHP: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `projekuas`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbprojek`
--

CREATE TABLE IF NOT EXISTS `tbprojek` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `nama` varchar(30) NOT NULL,
  `asal` varchar(30) NOT NULL,
  `nasional` int(3) NOT NULL,
  `internasional` int(3) NOT NULL,
  `perunggu` int(3) NOT NULL,
  `silver` int(3) NOT NULL,
  `emas` int(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1006 ;

--
-- Dumping data untuk tabel `tbprojek`
--

INSERT INTO `tbprojek` (`id`, `nama`, `asal`, `nasional`, `internasional`, `perunggu`, `silver`, `emas`) VALUES
(1001, 'Revo Avicena', 'Depok', 2, 2, 1, 1, 1),
(1002, 'Ahmad Agung kun', 'Jonggol', 3, 1, 2, 2, 0),
(1003, 'Budiman', 'Tangerang', 1, 1, 1, 0, 1),
(1004, 'Adil Wicaksono', 'Papua', 2, 2, 1, 1, 2);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
